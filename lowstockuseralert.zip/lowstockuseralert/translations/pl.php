<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_020598f1926d8c82af7bbaf83b849e9d'] = 'Alert niskiej dostępności w miniaturze produktu';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_004bab150e7a8c6ef0757a81d8fc77bf'] = 'Moduł dodający informację o niskiej dostępności produktu do miniatury';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_cebd5bbe0ffdecc270a8a324e5a277dd'] = 'Live Mode';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_ea9df7a306e2f8b5af37b67084d0c984'] = 'Używaj w Live Mode';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączony';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączony';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_88dd8872e02a00026fe8fdfd4538393d'] = 'Ilość';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_90b6eb2c243b6dfd0d759affdc08216b'] = 'Tekst';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_68244f868742fa9678b3c9af142897bb'] = 'Kolor czcionki';
$_MODULE['<{lowstockuseralert}prestashop>lowstockuseralert_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
